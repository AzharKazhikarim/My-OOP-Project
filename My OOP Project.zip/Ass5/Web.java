package Ass5;

import java.sql.Connection;
import java.sql.ResultSet;

public class Web extends Developers implements Projects {
    public boolean webChecker = false;


    @Override
    public void readDevelopers(int id) {
        try {
            Connection con = getConnection();
            statement = con.prepareStatement("SELECT * from employees WHERE id  = " + id);
            ResultSet result = statement.executeQuery();
            result.next();
            System.out.println(result.getInt("id") + " " +
                    result.getString("name") + " " +
                    result.getString("surname") + " " +
                    result.getString("position") + " Project: " + FirstProject);

        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public boolean checkerProject(String projectName){
        if(projectName.equals(SecondProject)){

            webChecker= false;
        }
        return  webChecker;
    }
}