package Ass5;
import java.sql.Connection;
import java.sql.ResultSet;


public class GameDev extends Developers implements Projects{
    public boolean checkerGameDev = false;

    @Override
    public void readDevelopers(int id) {
        try {
            Connection con = getConnection();
            statement = con.prepareStatement("SELECT * from employees WHERE id  = " + id);
            ResultSet result = statement.executeQuery();
            result.next();
            System.out.println(result.getInt("id") + " " +
                    result.getString("name") + " " +
                    result.getString("surname") + " " +
                    result.getString("position") + " Project: " + FirstProject);

        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public boolean checkerProject(String projectName){
        if(projectName.equals(FirstProject)) {
            checkerGameDev = true;
        }
        else{
            checkerGameDev = false;
        }
        return  checkerGameDev;
    }


}
