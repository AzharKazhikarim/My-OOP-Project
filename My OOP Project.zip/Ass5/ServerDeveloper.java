package Ass5;

import java.sql.Connection;
import java.sql.ResultSet;

public class ServerDeveloper extends Developers implements Projects{
    public boolean serverchecker = false;



    @Override
    public void readDevelopers(int id) {
        try {
            Connection con = getConnection();
            statement = con.prepareStatement("SELECT * from employees WHERE id  = " + id);
            ResultSet result = statement.executeQuery();
            result.next();
            System.out.println(result.getInt("id") + " " +
                    result.getString("name") + " " +
                    result.getString("surname") + " " +
                    result.getString("position") + "Project: " + FirstProject);

        } catch (Exception e) {
            System.out.println(e);
        }
    }
    @Override
    public boolean checkerProject(String projectName){
        if(projectName.equals(SecondProject)){
            serverchecker = true;
        }
        else {
            serverchecker = false;
        }
        return  serverchecker;
    }
}
