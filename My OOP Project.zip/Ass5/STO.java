package Ass5;
/*
This class is checked by STO each project and gives info about projects checked and passed by employees
RushMaquieen game is finished so that it's checked by each employee and STO also
 */
public class STO extends Workers implements Projects {

    public void checker(String project) {
        if (project.equals(FirstProject)) {
            Animator anim = new Animator();
            GameDev game = new GameDev();
            if ((anim.checkerProject(Projects.FirstProject))) {
                System.out.println("Animator: passed");
            } else {
                System.out.println("Animator: not passed");
            }
            if(game.checkerProject(Projects.FirstProject)){
                System.out.println("Game - Developer: passed");
            }else {
                System.out.println("Game - Developer: not passed");
            }
            if(anim.checkerProject(Projects.FirstProject) && game.checkerProject(Projects.FirstProject)) {
                System.out.println("STO: passed");
            }
            else {
                System.out.println("STO: Not passed");
            }

        }
        if (project.equals(SecondProject)) {

            Web web = new Web();
            ServerDeveloper sev = new ServerDeveloper();
            if ((web.checkerProject(Projects.SecondProject))) {
                System.out.println("Web-Developer: passed");
            } else {
                System.out.println("Web-Developer: not passed");
            }
            if(sev.checkerProject(Projects.SecondProject)){
                System.out.println("Server-Developer: passed");
            }else {
                System.out.println("Server-Developer: not passed");
            }
            if(web.checkerProject(Projects.SecondProject) && sev.checkerProject(Projects.SecondProject))
                System.out.println("STO: passed");
            else {
                System.out.println("STO: Not passed");
            }
        }


    }
}
