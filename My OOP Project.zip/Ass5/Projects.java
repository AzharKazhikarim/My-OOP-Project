package Ass5;
/*
This interface is store projects name, so we can extend it and change names without ant affect to other classes
 */
public interface Projects {
    String FirstProject = "RushMaquieen";
    String SecondProject = "Ticketon";

}

