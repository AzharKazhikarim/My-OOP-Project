package Ass5;

import java.sql.*;
/*
This class Workers is superclass of Developers and STO
Functionality: inserting all employees
 */

public  class Workers {

   static PreparedStatement statement;

    public static Connection getConnection() throws Exception {
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "2002");
            return con;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    public  void insert( String name, String surname,String position) throws Exception{
        try{
            Connection con = getConnection();
            statement =  con.prepareStatement("INSERT INTO employees(name,surname,position) VALUES(?,?,?)");
            statement.setString(1,name);
            statement.setString(2,surname);
            statement.setString(3,position);
            statement.executeUpdate();
        }catch (Exception e){
            System.out.println(e);
        }
        finally {
            System.out.println("Insert completed");
        }
    }


}
