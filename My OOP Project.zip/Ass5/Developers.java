package Ass5;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/*
Absrtact class Developers is more bigger than other with 3 methods, I am so sorry that I didn't use principle
"One class - one functionality", but I tried to do it more flexible.

Functionality: 1) calculate clear salary 2) insert employees level and salary respectively 3) calculate premium of employees
also 2 abstract methods : readDevelopers:  to connect with types of developers + Project which at they're working

checkerProject: Project passed or not info  for STO
 */

public abstract class Developers extends Workers{

    protected double middlepremium = 0.2, seniorpremium = 0.4;
    double maxopv = 42500*50;
    static PreparedStatement statement;
    Connection con = null;

    public  double getSalary(int id) throws Exception { //calculate clear employees salary info i got from EGOV
        int salarysize;
        double clearsal;
        con = getConnection();
        statement = con.prepareStatement("SELECT * from developers WHERE id  = " + id);
        ResultSet result = statement.executeQuery();
        result.next();
        salarysize = result.getInt("salary");
        double opv = salarysize * 0.1;
        clearsal = 0;
        if (maxopv > opv) {
            double ipn = ((salarysize - opv - 42500) * 0.1);
            if (salarysize > 42500) {
                clearsal = salarysize - opv - ipn;
            }
        }
        return clearsal;
    }

    public abstract void readDevelopers(int id);
    public abstract boolean checkerProject(String projectName);

    public  void insertDevelopersSalary(int id, String level, int salary) throws Exception{  //инсерт
        try{
            Connection con = getConnection();
            statement =  con.prepareStatement("INSERT INTO developers(id,level,salary) VALUES(?,?,?)");
            statement.setInt(1,id);
            statement.setString(2,level);
            statement.setInt(3,salary);
            statement.executeUpdate();
        }catch (Exception e){
            System.out.println(e);
        }
        finally {
            System.out.println("Insert completed");
        }
    }

    public double premium(int id) throws Exception {     //calculate premiums by level of developers
        double premuim = 0;

        try {
            con = getConnection();
            statement = con.prepareStatement("SELECT * from developers WHERE id  = " + id);
            ResultSet result = statement.executeQuery();
            result.next();
            String level = result.getString("level");
            int salary = result.getInt("salary");
            if (level.equals("Middle")) {
                premuim = salary * middlepremium;

            } else if (level.equals("Senior")) {
                premuim = salary * seniorpremium;

            } else {
                System.out.println("Does not have any premiums");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return premuim;
    }



}
