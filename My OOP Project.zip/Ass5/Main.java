package Ass5;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("Information about employee (EmpID,Name, Surname, Position, Project is:   ");
        GameDev gameDev = new GameDev();
        gameDev.readDevelopers(2);
        System.out.println("Clear salary : " + gameDev.getSalary(2));
        System.out.println("Premium is :" + gameDev.premium(2));

        System.out.println("*****************************************");
        System.out.println("Information about projects: ");
        STO sto =new STO();
        System.out.println("First project is game named 'RushMaquieen'");
        sto.checker("RushMaquieen");
        System.out.println("*****************************************");
        System.out.println("Second project is site named 'Ticketon'");
        sto.checker("Ticketon");





    }
}

